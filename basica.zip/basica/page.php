<div class="section section-breadcrumbs">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1><?=$d["name"]?></h1>
			</div>
		</div>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<!--<div class="col-sm-12">
				<img class="img-responsive" src="img/slides/1.jpg" alt="Full Width Banner Image">
			</div>-->
			<div class="col-sm-12">
				<!--<hr>-->
				<?=$d["content"]?>
			</div>
		</div>
	</div>
</div>