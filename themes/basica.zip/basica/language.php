<?php
	define("theme_home","Inicio");
	define("theme_login","Login");
	define("theme_read_more","Leer mas");
	define("theme_concact","Contactanos");
	define("theme_concact_address","Direccion");
	define("theme_concact_phone_one","Telefono");
	define("theme_concact_phone_two","Fax");
	define("theme_concact_email","Correo electronico");
	define("theme_our_social_networks","Nuestras redes sociales");
	define("theme_about_our_Company","Acerca de nuestra compañia");
?>